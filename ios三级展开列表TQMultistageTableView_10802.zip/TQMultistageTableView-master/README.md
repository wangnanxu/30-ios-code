TQMultistageTableView
=====================

一个可以3级展开的列表控件，每个header 或cell是互斥的，
点击一个，其他打开的收起。可以用来实现下面这样的效果
![Image text](http://github.com/TinyQ/TQMultistageTableView/raw/master/READMEIMAGE/TQTableView.gif)
![Image text](http://github.com/TinyQ/TQMultistageTableView/raw/master/READMEIMAGE/TQTableView2.gif)
