//
//  CustomLongPressGestureRecognizer.m
//  MessageList
//
//  Created by 刘超 on 13-11-12.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "CustomLongPressGestureRecognizer.h"

@implementation CustomLongPressGestureRecognizer

- (id)initWithTarget:(id)target action:(SEL)action
{
    self = [super initWithTarget:target action:action];
    if (self) {
        _label = [[OHAttributedLabel alloc] init];
    }
    
    return self;
}

@end
