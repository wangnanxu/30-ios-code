//
//  main.m
//  MessageList
//
//  Created by 刘超 on 13-11-12.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MessageListAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MessageListAppDelegate class]));
    }
}
