//
//  CustomLongPressGestureRecognizer.h
//  MessageList
//
//  Created by 刘超 on 13-11-12.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OHAttributedLabel.h"

@interface CustomLongPressGestureRecognizer : UILongPressGestureRecognizer

@property (assign) int currentNum;

@property (nonatomic, retain) OHAttributedLabel *label;

@end
