网易新闻下拉刷新Demo

![ScrrenShot](https://raw.github.com/phaibin/EGOTableViewPullRefresh/master/ScreenShot-1.png)

![ScrrenShot](https://raw.github.com/phaibin/EGOTableViewPullRefresh/master/ScreenShot-2.png)