//
//  AppDelegate.h
//  REPagedScrollViewExample
//
//  Created by Roman Efimov on 5/20/13.
//  Copyright (c) 2013 Roman Efimov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
