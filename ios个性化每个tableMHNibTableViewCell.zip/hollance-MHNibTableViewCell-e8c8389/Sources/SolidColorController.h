
/*
 * Demo for the SolidColorCell table view cells.
 */
@interface SolidColorController : UITableViewController
{
}

- (IBAction)accessoryControlTapped:(UIControl*)control withEvent:(UIEvent*)event;

@end
