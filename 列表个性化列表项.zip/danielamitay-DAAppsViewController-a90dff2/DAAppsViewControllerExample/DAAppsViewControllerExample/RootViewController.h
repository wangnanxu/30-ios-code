//
//  RootViewController.h
//  DAAppsViewControllerExample
//
//  Created by Daniel Amitay on 4/9/13.
//  Copyright (c) 2013 Daniel Amitay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UITableViewController

@end
