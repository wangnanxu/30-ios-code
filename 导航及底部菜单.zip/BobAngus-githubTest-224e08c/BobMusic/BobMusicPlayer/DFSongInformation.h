//
//  DFSongInformation.h
//  MusicPlayer
//
//  Created by Bill on 12-8-3.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MPMediaItem;

@interface DFSongInformation : NSObject

@property(retain,nonatomic)NSString *pinYin;
@property(assign,nonatomic)int index;

@end
