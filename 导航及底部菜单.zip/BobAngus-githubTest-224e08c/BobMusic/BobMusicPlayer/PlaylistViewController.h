//
//  PlaylistViewController.h
//  BobMusic
//
//  Created by Angus Bob on 12-11-4.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlaylistViewController : UIViewController//<UITableViewDelegate,UITableViewDataSource>

@end
