#import "StaticTextFieldTableViewCell.h"

@implementation StaticTextFieldTableViewCell

@synthesize contentTextField = _contentTextField;

@end