//
//  Lyrics.h
//  BobMusicPlayer
//
//  Created by Bob Angus on 12-10-12.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Lyrics : UIViewController
@property (weak, nonatomic) IBOutlet UITextView *textLyrics;

@end
