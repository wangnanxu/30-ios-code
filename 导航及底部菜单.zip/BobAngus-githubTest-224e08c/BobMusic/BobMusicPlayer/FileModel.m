//
//  MusicModel.m
//  BobMusic
//
//  Created by Angus Bob on 12-11-8.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "FileModel.h"


@implementation FileModel

@synthesize fileID;
@synthesize fileName;
@synthesize fileSize;
@synthesize isFistReceived;
@synthesize fileReceivedSize;
@synthesize fileURL;
@synthesize isDownloading;
@synthesize fileAlbumName;
@synthesize fileRoute;
@end
