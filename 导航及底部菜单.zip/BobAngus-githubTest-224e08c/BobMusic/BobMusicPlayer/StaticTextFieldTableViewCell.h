#import <Foundation/Foundation.h>
#import "JMStaticContentTableViewCell.h"

@interface StaticTextFieldTableViewCell : JMStaticContentTableViewCell

@property (nonatomic, strong) UITextField *contentTextField;

@end