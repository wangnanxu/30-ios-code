
//方法类型：自定义方法
//编   写：
//方法功能：全局变量
#define APPDELEGETE (AppDelegate *)[[UIApplication sharedApplication]delegate]