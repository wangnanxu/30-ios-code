//
//  HorizontalScreenViewController.h
//  BobMusic
//
//  Created by Angus Bob on 12-11-22.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <MediaPlayer/MediaPlayer.h>

@interface HorizontalScreenViewController : MPMoviePlayerViewController

@end
