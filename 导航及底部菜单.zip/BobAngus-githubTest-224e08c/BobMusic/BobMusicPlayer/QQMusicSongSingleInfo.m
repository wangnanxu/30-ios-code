//
//  QQMusicSongSingleInfo.m
//  BobMusic
//
//  Created by Angus Bob on 12-10-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "QQMusicSongSingleInfo.h"

@implementation QQMusicSongSingleInfo

@synthesize mSongUrl;
@synthesize mSongName;
@synthesize mSingerName;
@synthesize mAlbumName;
@synthesize mAlbumLink;
@synthesize mSongLrcUrl;
@synthesize mPlaytime;

@end
