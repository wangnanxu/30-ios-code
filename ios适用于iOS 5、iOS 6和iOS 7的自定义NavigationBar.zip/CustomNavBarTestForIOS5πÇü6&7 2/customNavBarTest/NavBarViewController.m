//
//  NavBarViewController.m
//  customNavBarTest
//
//  Created by JianYe on 13-8-12.
//  Copyright (c) 2013年 YingYing. All rights reserved.
//

#import "NavBarViewController.h"
#import "Navbar.h"
@interface NavBarViewController ()

@property (nonatomic,strong)IBOutlet UILabel     *label;
@end

@implementation NavBarViewController
@synthesize label = _label;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    if ([self.navigationController.viewControllers count]>1) {
        [self.navigationItem setNewTitle:@"测试"];
        [self.navigationItem setBackItemWithTarget:self action:@selector(back:)];
        [self.navigationItem setRightItemWithTarget:self action:@selector(resetStateBar) title:@"重置"];
       
    }
    self.navigationController.navigationBar.barStyle = UIBarStyleDefault;
   
    _label.text = [NSString stringWithFormat:@"%d",[self.navigationController.viewControllers count]];
}

- (void)viewWillAppear:(BOOL)animated
{
    if ([self.navigationController.viewControllers indexOfObject:self]==1) {
        Navbar *bar = (Navbar *)self.navigationController.navigationBar;
        bar.cusBarStyele = UIBarStyleDefault;
        bar.stateBarColor = [UIColor whiteColor];
    }
    
    [super viewWillAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    
    Navbar *bar = (Navbar *)self.navigationController.navigationBar;
    bar.cusBarStyele = UIBarStyleBlackOpaque;
    bar.stateBarColor = [UIColor blackColor];
    

    [super viewWillDisappear:animated];
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
   
}

- (IBAction)back:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)push:(id)sender
{
    NavBarViewController *controller = [[NavBarViewController alloc] initWithNibName:@"NavBarViewController" bundle:nil];
    [self.navigationController pushViewController:controller animated:YES];
}

- (void)resetStateBar
{
     Navbar *bar = (Navbar *)self.navigationController.navigationBar;
    [bar setDefault];
}
@end
