//
//  NavBarViewController.h
//  customNavBarTest
//
//  Created by JianYe on 13-8-12.
//  Copyright (c) 2013年 YingYing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NavBarViewController : UIViewController

@end
