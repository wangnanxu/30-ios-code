EKWelcomeView
=============

EKWelcomeView is a solution to implement entry/welcome/tutorial/hints view in application.  
E.g. you may use it for tutorial or for hints of how to use your application.

![alt tag](https://raw.github.com/EvgenyKarkan/EKWelcomeView/master/EKWelcomeView/EKWelcomeView/Classes/screenshot.png)


[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/EvgenyKarkan/ekwelcomeview/trend.png)](https://bitdeli.com/free "Bitdeli Badge")

