//
//  main.m
//  UICoreTextView
//
//  Created by Gilad Novik on 2013-01-17.
//  Copyright (c) 2013 Gilad Novik. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
	}
}
