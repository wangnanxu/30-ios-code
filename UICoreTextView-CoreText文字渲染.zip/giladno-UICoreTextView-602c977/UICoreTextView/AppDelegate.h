//
//  AppDelegate.h
//  UICoreTextView
//
//  Created by Gilad Novik on 2013-01-17.
//  Copyright (c) 2013 Gilad Novik. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
