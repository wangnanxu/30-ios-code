//
//  conciergeTests.m
//  conciergeTests
//
//  Created by Brendan Dixon on 2/14/11.
//  Copyright 2011 cultured inspiration. All rights reserved.
//

#import "conciergeTests.h"


@implementation conciergeTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in conciergeTests");
}

@end
