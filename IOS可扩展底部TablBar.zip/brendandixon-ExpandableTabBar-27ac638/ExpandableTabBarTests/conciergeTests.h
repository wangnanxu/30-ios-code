//
//  conciergeTests.h
//  conciergeTests
//
//  Created by Brendan Dixon on 2/14/11.
//  Copyright 2011 cultured inspiration. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface conciergeTests : SenTestCase {
@private
    
}

@end
